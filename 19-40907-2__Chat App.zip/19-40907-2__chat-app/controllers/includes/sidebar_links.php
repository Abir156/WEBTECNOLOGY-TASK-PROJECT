
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- <link rel="stylesheet" href="../Views/css/side-link.css"> -->
  
    <title>Document</title>
    <style>
      
        a{
            
            font-size: 18px;
             text-transform: uppercase;
    font-family: 'Roboto', sans-serif;
    font-weight: 900;
        }
       
    </style>
</head>

<body  >


<div class="side-links">
    <ul>

<li><a href="chat.php">Chat</a><br><br>
</li>
    </ul>
</div>
</body>
</html>